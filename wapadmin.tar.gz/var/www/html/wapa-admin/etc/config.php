<?php

$api_admin_url = 'http://localhost:8888';
$api_admin_port = '8888';

?>
