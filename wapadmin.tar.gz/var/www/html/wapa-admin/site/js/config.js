webpage="http://10.120.78.203"

apiurl="http://wapa-api.fibercorp.com.ar:8888"
