function showmessages(){
	$("#notif_indicador").off("click")
	$("#notif_indicador").on("click",function(){
		 hidemessages()
	})
	$("#notif").animate({
		bottom: "+=360",
	})
}

function hidemessages(){
	$("#notif_indicador").off("click")
	$("#notif_indicador").on("click",function(){
		showmessages()
	})
	$("#notif").animate({
		bottom: "-=360",
	})
}

function inicializar(){

	/* Inicializacion del menu */
	$('[data-sidenav]').sidenav()

	/* Inicializacion de mensajes */
	$("#notif_indicador").on("click",function(){
		showmessages()
	})

	/*Iniciamos el script que busca resutlados por API */
	setInterval(review_pending_tasks,5000)
}

function toggle_tareas() {
	$( "#effect" ).toggle( "slide", {}, 500 );
}

function modal_del_user(user_id){
	$( "#dialog-form" ).attr("title","Borrar usuario")
	dialog = $( "#dialog-form" ).dialog({
		autoOpen: false,
		height: 200,
		width: 300,
		modal: true,
		buttons: {
			"Aceptar": function(){ $(this).dialog("close"); del_user(user_id)}
			},
		Cancel: function(){$(this).dialog("close")}
	})
	$("#dialog-form").empty();
	$("#dialog-form").append("<div>Esta seguro de borar el usuario y todos sus datos?</div>");
	dialog.dialog( "open" )
}

function modal_add_user(){
	$( "#dialog-form" ).attr("title","Alta usuario")
	dialog = $( "#dialog-form" ).dialog({
		autoOpen: false,
		height: 400,
		width: 700,
		modal: true,
		buttons: {
			"Cancelar": function(){$(this).dialog("close")},
			"Aceptar": add_user
			
			},
		Cancel: function(){$(this).dialog("close")}
		})
	$("#dialog-form").empty();

	$("#dialog-form").append("<form><div class=\"form-table\">" + 
				 "<div class=\"table-row\">" +
				 "<div class=\"label\">username</div><div class=\"input\">" +
				 "<input class=\"text ui-widget-content ui-corner-all\" type=\"text\" name=\"name\" id=\"name\"></div>" + 
				 "</div>" +

				 "<div class=\"table-row\">" +
				 "<div class=\"label\">email</div><div class=\"input\">" +
				 "<input class=\"text ui-widget-content ui-corner-all\" type=\"text\" name=\"email\" id=\"email\"></div>" + 
				 "</div>" +
				
				 "<div class=\"table-row\">" +
				 "<div class=\"label\">contrase&ntilde;a</div><div class=\"input\">" +
				 "<input class=\"text ui-widget-content ui-corner-all\" type=\"text\" name=\"pass\" id=\"pass\"></div>" + 
				 "</div>" +
				 
				 "<div class=\"table-row\">" +
				 "<div class=\"label\">reingrese contrase&ntilde;a</div><div class=\"input\">" +
				 "<input class=\"text ui-widget-content ui-corner-all\" type=\"text\" name=\"pass2\" id=\"pass2\"></div>" + 
				 "</div></div></form>")

	dialog.dialog( "open" )
}


/*********************************
 *	Llamadas a la API	 *
 *********************************/

function make_bottom_menu(prefix, myarray){
	$("#acciones").empty()
	var arrayLength = myarray.length
	for(var i=0; i<arrayLength; i++){
		$("#acciones").append("<DIV id=\"" + prefix + myarray[i] + "\" class=\"action\"><IMG src=\"images/" + myarray[i]+ ".png\"></DIV>")
	}
}

function lista_nubes(){
	/* Genera el listado de nubes */
	
	$.ajax({
		type: "GET",
		url: webpage + "/api_admin_call.php?action=cloud_list",
		beforeSend: function(){
			$("#body").empty();
			$("#body").append("<img id=\"wait_clud_list\" src=\"images/wait.gif\" style=\"width:60px\">");
		},
		success : function(data){
			var obj = JSON.parse(data)
			if(!obj){
				alert("ERROR")
			} else {
				$("#body").empty()
				var acciones = []
				listado_crear("body","lista_nubes",{"Nombre":"name","tipo":"type","Estado":"status"},obj.info,"cloud_actions","cloud_info")
			}
		},
		error: function(){alert("task_id: ERROR AJAX" + webpage + "/api_admin_call.php?action=cloud_list")}
	})
}


function lista_usuarios(){
	/* Genera el listado de usuarios */
	$.ajax({
		type: "GET",
		url: webpage + "/api_admin_call.php?action=user_list",
		beforeSend: function(){
			$("#body").empty();
			$("#body").append("<img id=\"wait_user_list\" src=\"images/wait.gif\" style=\"width:60px\">");
		},
		success : function(data){
			//alert(data)
			var obj = JSON.parse(data)
			if(!obj){
				alert("ERROR")
			} else {
				$("#body").empty()
				var acciones = []
				acciones[0] = {"name": "del_user","icon":"images/trash.png","onclick":"del_user"}
				acciones[1] = {"name": "change_user_pass","icon":"images/password.png","onclick":"change_user_pass"}
				listado_crear("body","lista_usuarios",{"Nombre":"name","Email":"email","Estado":"status"},obj.info,"user_actions")
			}
		},
		error: function(){alert("task_id: ERROR AJAX" + webpage + "/api_admin_call.php?action=user_list")}
	})
}

function datos_usuario(user_id){
	/* Arma el formulario con todos los datos del usuario */
	$.ajax({
		type: "GET",
		url: webpage + "/api_admin_call.php?action=user_info&user_id=" + user_id,
		beforeSend: function(){
			$("#contuserlist").empty();
			$("#contuserlist").append("<img id=\"wait_user_list\" src=\"images/wait.gif\">");
		},
		success : function(data){
			var obj = JSON.parse(data)
			if(!obj){
				alert("ERROR")
			} else {
				$("#contuserlist").empty();
				$("#contuserlist").append("<INPUT value=\"" + obj.name + "\">")
				$("#contuserlist").append("<INPUT value=\"" + obj.email + "\">")
			}
		},
		error: function(){alert("task_id: ERROR AJAX")}
	})
}

function user_actions(user_id){
	return "<div><img src=\"images/add.png\" onclick=\"modal_add_user()\"></div>" +
		"<div><IMG src=\"images/trash.png\" onclick=\modal_del_user(" + user_id + ")></div>" +
		"<div><IMG src=\"images/password.png\" onclick=\"modal_user_password(" + user_id + ")\"></div>"
}

function modal_user_password(user_id){
	dialog = $( "#dialog-form" ).dialog({
		autoOpen: false,
		height: 600,
		width: 350,
		modal: true,
		buttons: {
			"Aceptar": change_user_password
		}
	})
	$("#dialog-form").empty();
	$("#dialog-form").append("<form><fieldset id=\"dialog-form-fields\"></fieldset></fieldset></form>")
	$("#dialog-form-fields").append("<label for=\"name\">Password</label><BR>")
	$("#dialog-form-fields").append("<input type=\"password\" name=\"name\" id=\"name\" class=\"text ui-widget-content ui-corner-all\"><BR>")
	$("#dialog-form-fields").append("<label for=\"name\">Password Again</label><BR>")
	$("#dialog-form-fields").append("<input type=\"password\" name=\"name\" id=\"name\" class=\"text ui-widget-content ui-corner-all\">")
      	dialog.dialog( "open" )
}

function del_user(user_id){
	//dialog.dialog( "close")

	$.ajax({
		type: "DELETE",
		url: apiurl + "/users/" + user_id,
		success: function(data){
			var obj = JSON.parse(data)
			if(!obj){
				alert("ERROR: " + data)
			} else {
				if(obj.status == "TODO"){
					add_task(obj.task,"Borrado usuario")
				} else if(obj.status == "ERROR"){
					alert(obj.data)
				}
			}
		}
	})
}

function add_user(){
	/* Enviamos el alta del usuario */
	/* Agregamos la tearea */
	dialog.dialog( "close" )
	name = $("#name").val()
	pass = $("#pass").val()
	email = $("#email").val()
	//alert(name + " | " + pass + " | " + email);
	$.ajax({
		type: "POST",
		url: apiurl + "/users",
		data: { "name":name , "pass":pass , "email":email},
		success: function(data){
			var obj = JSON.parse(data)
                        if(!obj){
                                alert("ERROR: " + data)
                        } else {
				if(obj.status == "TODO"){
					add_task(obj.task,"Alta usuario")
				} else if(obj.status == "ERROR"){
					alert(obj.data)
				}
			}
		},
		error: function(jqXHR, textStatus, errorThrown){ alert("Error add_user: " + textStatus + " | " + errorThrown) }
	})
}

function submenu(padre,opciones,id){

	aux = "<div id=\"menu_h\" class=\"menu_h\">"
	for(var key in opciones){
		aux = aux + "<span onclick=\"" + opciones[key] + "(" + id + ")\">" + key + "</a></span>"
	}
	aux = aux + "</div>"
	$("#" + padre).append(aux)
}

function lista_servers_cloud(cloudid){
	alert("listamos los servidores " + cloudid);
	$.ajax({
		type: "GET",
		url: webpage + "/api_admin_call.php?action=server_list&id=" + cloudid,
		beforeSend: function(){
			$("#body").empty();
			$("#body").append("<img id=\"wait_clud_list\" src=\"images/wait.gif\" style=\"width:60px\">");
		},
		success : function(data){
			alert(data)
			var obj = JSON.parse(data)
			if(!obj){
				alert("ERROR")
			} else {
				$("#body").empty()
				var acciones = []
				listado_crear("body","lista_servers",{"Nombre":"name","Rol":"rol","Status":"status"},obj.info,"","")
			}
		},
		error: function(){alert("task_id: ERROR AJAX" + webpage + "/api_admin_call.php?action=server_list")}
	})

}
function lista_sitios_cloud(cloudid){
	alert("listamos los sitios");
	$.ajax({
		type: "GET",
		url: webpage + "/api_admin_call.php?action=site_list&id=" + cloudid,
		beforeSend: function(){
			$("#body").empty();
			$("#body").append("<img id=\"wait_site_list\" src=\"images/wait.gif\" style=\"width:60px\">");
		},
		success : function(data){
			var obj = JSON.parse(data)
			if(!obj){
				alert("ERROR")
			} else {
				$("#body").empty()
				var acciones = []
				listado_crear("body","lista_sitios",{"Nombre":"name","Estado":"status"},obj.info,"site_actions","site_info")
			}
		},
		error: function(){alert("task_id: ERROR AJAX" + webpage + "/api_admin_call.php?action=site_list")}
	})

}

function cloud_info(id_cloud){
	//alert("cloud " + id_cloud)

	$("#body").empty()

	/* Armamos el submenu */
	submenu("body",{"Servers":"lista_servers_cloud","Sitios":"lista_sitios_cloud"},id_cloud)

	$.ajax({
		type: "GET",
		url: webpage + "/api_admin_call.php?action=user_info&user_id=" + user_id,
		beforeSend: function(){
			$("#contuserlist").empty();
			$("#contuserlist").append("<img id=\"wait_user_list\" src=\"images/wait.gif\">");
		},
		success : function(data){
			var obj = JSON.parse(data)
			if(!obj){
				alert("ERROR")
			} else {
				$("#contuserlist").empty();
				$("#contuserlist").append("<INPUT value=\"" + obj.name + "\">")
				$("#contuserlist").append("<INPUT value=\"" + obj.email + "\">")
			}
		},
		error: function(){alert("task_id: ERROR AJAX")}
	})
}
