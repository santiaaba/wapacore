<?php

function menu_iz(){

	# Imprime el menu 

	echo '<ul class="menuRoot" id="menu">';
		echo '<li><a onclick="lista_nubes()"><div class="menuRoot_img"><img src="images/menu_nubes.png"></div><div class="menuRoot_text">Nubes</div></a></li>';
		echo '<li><a onclick="lista_usuarios()"><div class="menuRoot_img"><img src="images/menu_usuarios.png"></div><div class="menuRoot_text">Usuarios</div></a></li>';
	echo '</ul>';
}
?>
