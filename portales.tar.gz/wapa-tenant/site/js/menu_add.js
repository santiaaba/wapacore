function menu_add_init(data){
	/* data es un array donde cada elemento consta de tres campos
 		nombre: Nombre a mostrar
		img: Imagen a mostrar
		accion: accion a mostrar
 	*/
	/* Iniciamos el tamano */
	$("#menu_add").css("top",$( window ).height())
	$("#menu_add").css("height",$( window ).height())
	$("#menu_add_icon").on("click",function(){
		show_menu_add()
	})

	for(var key in data){
		$("#menu_add_menu").append("<div onclick=\"form_add_user('menu_add_data')\"><span><img src=\"images/" +
		data[key][1] + "\"></span><span style=\"padding-left:20px\">" +
		data[key][0] + "</span></div>")
	}
}

function show_menu_add(){
	$("#menu_add_icon").off("click")
	//alert("altura: " + $( window ).height())
	$("#menu_add").animate({
		//height: "+=" + $( window ).height(),
		top: "-=" + $( window ).height(),
		},{
		done: function(){
			$("#menu_add_menu").children().addClass('hover')
			$(window).keydown(function(e){
				if(e.key === "Escape"){
					hidden_menu_add()
					//$(window).unbind("keydown")
				}
			})
		}
	})
}

function hidden_menu_add(){
	$(window).unbind("keydown")
	$("#menu_add_icon").on("click",function(){
		show_menu_add()
	})
	$("#menu_add_data").empty()
	$("#menu_add").animate({
		top: "+=" + $( window ).height(),
		//height: "-=" + $( window ).height(),
		},{
		start: function(){
			$("#menu_add_menu").children().removeClass('hover')
			}
		}
	)
}
