function listado_crear(padre,nombre,columnas,datos,acciones,dblclick){
	/*padre es el objeto padre donde se creara el listado. Generalmente un <div>*/
	/* nombre es el nombre del listado */
	/* columnas es un array asociativo donde la key es el nombre de la columna y el valor es
 	   el nombre del dato dentro de datos */
	/* datos es un array de array con los datos del listado. Deben cotener si o si un campo id */
	/* acciones es el nombre de la funcion que genera las acciones dada la id de cada fila*/
	/*dblclick es el nombre de la funcion a invocar al hacer doble click. Se pasa siempre el id de datos */

	aux = "<table><tr>"
	for(var key in columnas){
		aux = aux + "<td>" + key + "</td>"
	}
	aux = aux + "</tr></table>"

	$("#" + padre).append("<div id=\"" + nombre + "\" class=\"listado\">" +
			     "<div class=\"listado-cabecera\">" +
				aux +
			     "</div>" +
			     "<div class=\"listado-cuerpo\">" +
				"<table id=\"listado-items-" + nombre + "\"></table>" +
			     "</div>" +
			     "<div id=\"listado-acciones-" + nombre + "\" class=\"listado-actions\">" +
			     "</div>" +
			  "</div>");

	var arrayLength = datos.length

	for(var i=0; i<arrayLength; i++){
		fila = ""
		for(var key in columnas){
			fila = fila + "<TD>" + datos[i][columnas[key]] + "</TD>"
		}
		$("#listado-items-" + nombre).append("<TR iid=\"" + datos[i].id + "\" id=\"listado-item-" + nombre +
					"-" + datos[i].id + "\" onClick=\"listado_change_actions(\'" +
					nombre + "\',\'" + datos[i].id + "\',\'" + acciones + "\')\">" + fila + "</tr>")
		$("#listado-item-" + nombre + "-" + datos[i].id).dblclick(function(){ window[dblclick]($(this).attr("iid"))})
	}
}

function listado_change_actions(nombre,id,acciones){
	/*Desseleccionamos en alterior */
	$("#listado-items-" + nombre + " tr").removeClass("listado-selected")

	/*seleccionamos el actual */
	$("#listado-item-" + nombre + "-" + id).addClass("listado-selected")

	/* Armamos el menu para el item */
	$("#listado-acciones-" + nombre).empty()
	if(acciones){
		$("#listado-acciones-" + nombre).append(window[acciones](id))
	}
	

}
