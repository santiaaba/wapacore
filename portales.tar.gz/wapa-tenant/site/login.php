<?php

include "../php/genericas.php";

?>

<HTML>
	<HEAD>
	</HEAD>
	<BODY>
		<div>
			<form>
				<input>
				<input>
				<input type="submit" value="autenticar">
			</form>
		</div>
	</BODY>
</HTML>
