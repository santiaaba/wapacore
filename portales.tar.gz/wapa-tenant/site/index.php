<?php

include "../php/genericas.php";

?>
<HTML>
	<HEAD>
		<script src="js/jquery-3.3.1.min.js"></script>
		<script src="js/jquery-ui.min.js"></script>
		<script src="js/config.js"></script>
		<script src="js/tasks.js"></script>
		<script src="js/funciones.js"></script>
		<script src="js/listado.js"></script>
		<script src="js/menu_iz.js"></script>
		<script src="js/sidenav.min.js"></script>
		<script src="js/menu_add.js"></script>

		<link rel="stylesheet" type="text/css" href="css/sidenav.css">
		<link rel="stylesheet" type="text/css" href="css/jquery-ui.min.css">
		<link rel="stylesheet" type="text/css" href="css/jquery-ui.structure.min.css">
		<link rel="stylesheet" type="text/css" href="css/jquery-ui.theme.css">
		<link rel="stylesheet" type="text/css" href="css/estilos.css">
		<link rel="stylesheet" type="text/css" href="css/listado.css">
		<link rel="stylesheet" type="text/css" href="css/menu_iz.css">

		<script>
			var dialog
			$(function(){inicializar()})
		</script>

	</HEAD>
	<BODY>

		<!-- Para el popup -->
		<div id="dialog-form"></div>

		<!-- Pagina principal -->
		<div id="container" class="ui-widget container">
			<div class="header">
				Va el header
			</div>
			<div class="content">
				<div class="menu_izquierda">
					<?php
						menu_iz();
					?>
				</div>
				<div class="content2">
					<div id="body" class="body">
						Va el contenido
					</div>
					<div class="footer">
						<div class="notif" id="notif">
							<div class="notif_indicador noselect ui-corner-top" id="notif_indicador">
								Mensajes
							</div>
							<div class="notif_contenido" id="notif_contenido">
								<!--
								<img src="nada" onclick="add_task('123123123','alta de cliente')">
								<img src="nada" onclick="review_pending_tasks()">
								-->
								<img src="images/cancelar.png" onclick="remove_all()">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php  menu_add(); ?>

	</BODY>
</HTML>
