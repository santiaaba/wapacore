<?php

include "../etc/config.php";

function task_get($api_admin_url,$task_id){
	/* Solicita al core el resultado de un task */
	$endloop = 0;	// No tenemos aun el resultado
	$times = 10;

	//echo "Entro task_get -$task_id-\n";
	while(!$endloop && $times > 0){
		$curl = curl_init($api_admin_url . "/task/" . $task_id);
		curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
		$result = curl_exec($curl);
		$obj = json_decode($result,true);
		//var_dump($obj);
		if($obj{'status'} == "waiting" or $obj{'status'} == "todo"){
			sleep(2);
			$times--;
		} else {
			$endloop = 1;
		}
		curl_close($curl);
	}
	//echo "salio $endloop $times<BR>";
	if($obj{'status'}== "done"){
		//echo "entro if\n";
		echo json_encode($obj{'data'});
		//echo $result;
	} else {
		echo '';
	}
}

function task_get_send($api_admin_url,$string){

	$curl = curl_init("$api_admin_url/$string");
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	$result = curl_exec($curl);
	curl_close($curl);

	if($result){
		$obj = json_decode($result);
		//echo "Buscando resultado " + $obj->{'task'} + "\n";
		task_get($api_admin_url,$obj->{'task'});
	} else {
		echo "{\"code\":\"500\",\"info\":\"API no responde\"}";
	}
}

function cloud_list($api_admin_url,$api_admin_port){

	$curl = curl_init("http://$api_admin_url:$api_admin_port/clouds");
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	$result = curl_exec($curl);
	curl_close($curl);

	if($result){
		$obj = json_decode($result);
		//echo "Buscando resultado\n";
		task_get($api_admin_url,$api_admin_port,$obj->{'task'});
	} else {
		echo "{\"code\":\"500\",\"info\":\"API no responde\"}";
	}
}

/* Main */

switch ($_GET['action']){
	case 'user_list':
		task_get_send($api_admin_url,"users");
		break;
	case 'cloud_list':
		task_get_send($api_admin_url,"clouds");
		break;
	case 'user_info':
		task_get_send($api_admin_url,"users/" . $_GET['id']);
		break;
	case 'server_list':
		task_get_send($api_admin_url,"webhosting/" . $_GET['id'] . "/servers");
		break;
	case 'site_list':
		task_get_send($api_admin_url,"webhosting/" . $_GET['id'] . "/sites");
		break;
	case 'plan_list':
		task_get_send($api_admin_url,"plans/" . $_GET['id']);
		break;
	default:
		echo "error";
}
?>
