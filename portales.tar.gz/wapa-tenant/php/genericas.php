<?php

function menu_iz(){

	# Imprime el menu 

	echo '<ul class="menuRoot" id="menu">';
		echo '<li><a onclick="lista_nubes()"><div class="menuRoot_img"><img src="images/menu_nubes.png"></div><div class="menuRoot_text">Nubes</div></a></li>';
		echo '<li><a onclick="lista_usuarios()"><div class="menuRoot_img"><img src="images/menu_usuarios.png"></div><div class="menuRoot_text">Usuarios</div></a></li>';
		echo '<li><a onclick="lista_planes()"><div class="menuRoot_img"><img src="images/menu_planes.png"></div><div class="menuRoot_text">Planes</div></a></li>';
	echo '</ul>';
	echo '<div id="menu_add_icon" class="menu_add_icon"><span><img src="images/add.png">';
	echo '</span><span style="padding-left:20px;">Agregar</span></div>';
}

function menu_add(){
	# Arma el menu de adicion
	echo '<div id="menu_add" class="menu_add">';
		echo '<div id="menu_add_menu" class="menu_add_menu">';
		echo '</div>';
		echo '<div id="menu_add_data" class="menu_add_data"></div>';
	echo '</div>';
}

?>
