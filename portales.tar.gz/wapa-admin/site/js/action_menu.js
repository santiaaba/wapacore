function action_menu_add(contenedor,item_id,image,f){
	$("#" + contenedor).append("<div id=\"" + contenedor + "_" + item_id + "\"><img src=\"" + image + "\"></div>")
	$("#" + contenedor + "_" + item_id).on("click",f)
}

function action_menu_del(contenedor,item_id){
	$("#" + contenedor + "_" + item_id).remove()
}
