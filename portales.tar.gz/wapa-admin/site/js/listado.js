function listado_crear(padre,nombre,columnas,datos,select,dblclick){
	/* padre: Nombre objeto padre donde se creara el listado. Generalmente un <div>*/
	/* nombre: Nombre del listado */
	/* columnas: array asociativo donde la key es el nombre de la columna y el valor es el nombre del dato dentro de datos */
	/* datos: Array de array con los datos del listado. Deben cotener si o si un campo id */
	/* select: Nombre de la funcion a llamar cuando se selecciona una fila*/
	/* dblclick: Nombre de la funcion a invocar al hacer doble click. Se pasa siempre el id de datos */

	aux = "<table><tr>"
	for(var key in columnas){
		aux = aux + "<td>" + key + "</td>"
	}
	aux = aux + "</tr></table>"

	$("#" + padre).append("<div id=\"" + nombre + "\" class=\"listado\">" +
			     "<div class=\"listado-cabecera\">" +
				aux +
			     "</div>" +
			     "<div class=\"listado-cuerpo\">" +
				"<table id=\"listado-items-" + nombre + "\"></table>" +
			     "</div>" +
			     "<div id=\"listado-acciones-" + nombre + "\" class=\"listado-actions\">" +
			     "</div>" +
			  "</div>");

	var arrayLength = datos.length

	for(var i=0; i<arrayLength; i++){
		fila = ""
		for(var key in columnas){
			fila = fila + "<TD>" + datos[i][columnas[key]] + "</TD>"
		}
		$("#listado-items-" + nombre).append("<TR iid=\"" + datos[i].id + "\" id=\"listado-item-" + nombre +
					"-" + datos[i].id + "\" onClick=\"listado_change_actions(\'listado-acciones-" +
					nombre + "\',\'" + datos[i].id + "\',\'" + select + "\')\">" + fila + "</tr>")
		$("#listado-item-" + nombre + "-" + datos[i].id).dblclick(function(){ window[dblclick]($(this).attr("iid"))})
	}
}

function listado_change_actions(nombre,id,select){
	/*Desseleccionamos en alterior */
	$("#listado-items-" + nombre + " tr").removeClass("listado-selected")

	/*seleccionamos el actual */
	$("#listado-item-" + nombre + "-" + id).addClass("listado-selected")

	/* llamamos a la funcion de seleccion */
	window[select](id,nombre)
}
